var searchData=
[
  ['direction_189',['Direction',['../namespace_tiny_math.html#a48e23d26a9eca1bf13236a7df8ce5385',1,'TinyMath']]]
];
