var searchData=
[
  ['center_163',['center',['../class_text_field.html#a6ba6b0b14dfa3fea37d62765b41b5a01',1,'TextField']]],
  ['color_164',['color',['../class_game_object.html#a1d3ba0ee5ea2c12727356cb50f3d659b',1,'GameObject']]]
];
