var searchData=
[
  ['initial_5fball_5fvelocity_169',['INITIAL_BALL_VELOCITY',['../_game_8hpp.html#a75945de6045e82fca6af6061d1d7f13d',1,'Game.hpp']]],
  ['issolid_170',['isSolid',['../class_game_object.html#a975046eeccf3433f0730d365ea967d0e',1,'GameObject']]]
];
