var searchData=
[
  ['vectordirection_155',['VectorDirection',['../namespace_tiny_math.html#a131b24e2818bb7e155eb3357097b5a80',1,'TinyMath']]]
];
