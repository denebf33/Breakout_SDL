var searchData=
[
  ['init_36',['Init',['../class_game.html#a555a9e4719fd49971765a2ab8b090b5c',1,'Game']]],
  ['initial_5fball_5fvelocity_37',['INITIAL_BALL_VELOCITY',['../_game_8hpp.html#a75945de6045e82fca6af6061d1d7f13d',1,'Game.hpp']]],
  ['iscompleted_38',['IsCompleted',['../class_game_level.html#afe7683ad46e3b404a2b14e2cb03f86f0',1,'GameLevel']]],
  ['issolid_39',['isSolid',['../class_game_object.html#a975046eeccf3433f0730d365ea967d0e',1,'GameObject']]]
];
