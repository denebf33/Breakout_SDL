var searchData=
[
  ['ball_5fradius_117',['BALL_RADIUS',['../_game_8hpp.html#a9beb30db31ead6ed731990297859f0b7',1,'Game.hpp']]],
  ['ballobject_118',['BallObject',['../class_ball_object.html#ac2106a42734e5028b3be1a38e8c39e31',1,'BallObject::BallObject()'],['../class_ball_object.html#ac6d402781268fb9171b8a241e09a99f9',1,'BallObject::BallObject(TinyMath::Vec2 pos, float radius, TinyMath::Vec2 velocity, SDL_Surface *sprite, SDL_Renderer *renderer)']]]
];
