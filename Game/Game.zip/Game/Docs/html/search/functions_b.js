var searchData=
[
  ['textfield_153',['TextField',['../class_text_field.html#ae5ddf6e38ead3199cf040f183c51e362',1,'TextField::TextField(TinyMath::Vec2 position, SDL_Renderer *renderer, TTF_Font *font, std::string lang, int width, int height, bool center=false)'],['../class_text_field.html#a53f7984c4c2f5b734568fc29da2fa8bf',1,'TextField::TextField()']]]
];
