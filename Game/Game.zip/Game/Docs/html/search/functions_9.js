var searchData=
[
  ['render_147',['Render',['../class_game.html#a0897730fc9fed789f6c0f11d21a0c14a',1,'Game']]],
  ['reset_148',['Reset',['../class_ball_object.html#a5a9db03f9493003615a510b24d279603',1,'BallObject']]],
  ['resetlevel_149',['ResetLevel',['../class_game.html#ace85e926f2bf391130fdd1298122ef1f',1,'Game']]],
  ['resetplayer_150',['ResetPlayer',['../class_game.html#a87d7c3fa094e6d401d2a040087070831',1,'Game']]]
];
