var searchData=
[
  ['init_133',['Init',['../class_game.html#a555a9e4719fd49971765a2ab8b090b5c',1,'Game']]],
  ['iscompleted_134',['IsCompleted',['../class_game_level.html#afe7683ad46e3b404a2b14e2cb03f86f0',1,'GameLevel']]]
];
